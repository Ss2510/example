package com.dieboldnixdorf.sbt.report.services.test;

import com.dieboldnixdorf.sbt.report.services.SbtEis;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.ExtendedResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.cdi.util.ServiceTestHandler;
import com.dieboldnixdorf.txm.core.businessmodel.container.ClientContext;
import com.dieboldnixdorf.txm.core.businessmodel.container.Request;
import com.dieboldnixdorf.txm.core.businessmodel.container.SessionHandlingInstruction;
import com.dieboldnixdorf.txm.core.businessmodel.container.TransactionStep;
import com.dieboldnixdorf.txm.core.businessmodel.services.ResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.ServiceResponse;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.TransactionService;
import org.jboss.arquillian.testng.Arquillian;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.inject.Inject;
import java.time.Instant;
import java.util.HashMap;

public class SbtEisTest extends Arquillian {

    @Inject
    @TransactionService(id = SbtEis.SERVICE_ID)
    private SbtEis service;

    @Inject
    private ServiceTestHandler serviceTestHandler;

    @Test
    public void testSbtEis(){
        // create new request
        Request request = new  Request.Builder()
                .sessionHandlingInstruction(SessionHandlingInstruction.INTERMEDIATE_REQUEST)
                .transactionStepId(1)
                .clientId("TEST_CLIENT")
                .time(Instant.now())
                .transactionId(1)
                .build();

        // create transaction step
        ClientContext clientContext = new ClientContext(request.getHeader().getClientId());
        TransactionStep step = clientContext.createConsumerSession().createTransaction().createTransactionStep(request);

        // call service
        ServiceResponse response = serviceTestHandler.callWithTestContext(service, step, new HashMap<>());

        // check service response
        Assert.assertEquals(response.getResponseCode(), ResponseCode.OK);
        Assert.assertEquals(response.getExtendedResponseCode(), ExtendedResponseCode.OK);
    }
}
