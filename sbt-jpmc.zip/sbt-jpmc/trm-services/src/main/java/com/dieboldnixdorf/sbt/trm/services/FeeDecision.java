package com.dieboldnixdorf.sbt.trm.services;

import com.dieboldnixdorf.sbt.trm.SbtExtendedResponseCodes;
import com.dieboldnixdorf.sbt.trm.businessobjects.TimeSinceLastTransaction;
import com.dieboldnixdorf.sbt.trm.config.TRConfig;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.ExtendedResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.container.Request;
import com.dieboldnixdorf.txm.core.businessmodel.container.TransactionStep;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumer;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumerStrategy;
import com.dieboldnixdorf.txm.core.businessmodel.services.ResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.Service;
import com.dieboldnixdorf.txm.core.businessmodel.services.ServiceImplementation;
import com.dieboldnixdorf.txm.core.businessmodel.services.ServiceResponse;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.ExtRspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.RspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.TransactionService;
import com.myproclassic.common.logging.PCETrace;
import com.myproclassic.common.tservices.tracelog.aspects.PCEAopTrace;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@PCEAopTrace
@ApplicationScoped
@TransactionService(id = FeeDecision.SERVICE_ID,
                    usage = "Apply Fees based on Timeout value",
                    serviceGroup = "SBT",
                    rspCodes = {
                        @RspCode(value = ResponseCode.OK, extRspCodes = {
                                @ExtRspCode(value = ExtendedResponseCode.OK_ID, name = "Fee applied")
                        }),
                        @RspCode(value = ResponseCode.OK, extRspCodes = {
                                @ExtRspCode(value = SbtExtendedResponseCodes.FEE_REQUIRED_ID,
                                            name = "Fee required" )
                        }),
                        @RspCode(value = ResponseCode.FAIL, extRspCodes = {
                                @ExtRspCode(value = ExtendedResponseCode.SERVER_FAILURE_ID, name = "Fee apply failed")
                        })
                    })
public class FeeDecision implements Service {
    public static final String SERVICE_ID = "feeDecision" ;

    @Inject
    @FacetConsumerStrategy(value = Request.class)
    private FacetConsumer<TimeSinceLastTransaction> fcTimeSinceLastTransaction;

    @Inject
    private TRConfig configuration;

    private ServiceResponse implementation(TransactionStep step, Map<String, String> parameter) throws Exception {
        Optional<TimeSinceLastTransaction> opt = fcTimeSinceLastTransaction.getOptional();

        if (configuration != null && opt.isPresent()) {

            TimeSinceLastTransaction elapsedTime = fcTimeSinceLastTransaction.get();

            // transactions called BEFORE timeout should include a fee
            int feeCalculationTimeout = Integer.valueOf(configuration.getFeeCalculationTimeout());
            PCETrace.trace("Fee Calculation Timeout: {}", feeCalculationTimeout);
            PCETrace.trace("Elapsed Time to Min : {}", TimeUnit.MILLISECONDS.toMinutes(elapsedTime.getElapsedTime()));

            if (elapsedTime.getElapsedTime() == 0
                    || (TimeUnit.MILLISECONDS.toMinutes(elapsedTime.getElapsedTime())) > feeCalculationTimeout) {
                // after timeout - return ok (no fee)
                return ServiceResponse.success(ExtendedResponseCode.OK);
            } else {
                // before timeout - return fee required
                return ServiceResponse.success(SbtExtendedResponseCodes.FEE_REQUIRED);
            }
        } else {
            return ServiceResponse.failure();
        }
    }

    @Override
    public ServiceResponse apply(TransactionStep transactionStep, Map<String, String> map) {
        return ServiceImplementation.create().apply(this::implementation,transactionStep,map);
    }
}
