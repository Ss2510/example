package com.dieboldnixdorf.sbt.trm.services;

import com.dieboldnixdorf.sbt.trm.businessobjects.PurchaseAmount;
import com.dieboldnixdorf.sbt.trm.businessobjects.TimeSinceLastTransaction;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.ExtendedResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.container.TransactionStep;
import com.dieboldnixdorf.txm.core.businessmodel.context.accessor.annotations.PostProcessContext;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumer;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumerStrategy;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetProducer;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetProducerStrategy;
import com.dieboldnixdorf.txm.core.businessmodel.services.ResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.Service;
import com.dieboldnixdorf.txm.core.businessmodel.services.ServiceResponse;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.ExtRspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.RspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.TransactionService;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Amount;
import com.myproclassic.common.tservices.tracelog.aspects.PCEAopTrace;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;

@PCEAopTrace
@ApplicationScoped
@TransactionService(id = CollectDataService.SERVICE_ID,
                    usage = "Data Collection Service",
                    serviceGroup = "SBT",
                    rspCodes = {
                        @RspCode(value = ResponseCode.OK, extRspCodes = {
                            @ExtRspCode(value = ExtendedResponseCode.OK_ID,
                                        name = "Data Collected")
                        }),
                        @RspCode(value=ResponseCode.FAIL, extRspCodes = {
                            @ExtRspCode(value = ExtendedResponseCode.SERVER_FAILURE_ID,
                                        name = "Data Collection Failed")
                        })
                    })
public class CollectDataService implements Service {
    public static final String SERVICE_ID = "CollectDataService" ;

    @Inject
    @PostProcessContext
    @FacetConsumerStrategy(mandatory = true)
    FacetConsumer<PurchaseAmount> purchaseAmountConsumer;

    @Inject
    @PostProcessContext
    @FacetProducerStrategy(mandatory = true)
    FacetProducer<PurchaseAmount> purchaseAmountFacetProducer;

    @Inject
    @PostProcessContext
    @FacetConsumerStrategy(mandatory = true)
    FacetConsumer<TimeSinceLastTransaction> timeSinceLastTransactionFacetConsumer;


    @Override
    public ServiceResponse apply(TransactionStep step, Map<String, String> parameter) {
        System.out.println("Correlation ID: " + step.getRequest().getHeader().getCorrelationId());

        Optional<PurchaseAmount> purchaseAmountOptional = purchaseAmountConsumer.getOptional();
        Optional<PurchaseAmount> purchaseAmountOptional1 =  purchaseAmountFacetProducer.getOptional();
        Optional<TimeSinceLastTransaction> timeSinceLastTransactionOptional =
                timeSinceLastTransactionFacetConsumer.getOptional();

        if (purchaseAmountOptional.isPresent()) {
            Amount purchaseAmount = purchaseAmountOptional.get().getRequestedAmount();
            System.out.println("purchase amount: " + purchaseAmount.getValue() + " " + purchaseAmount.getCurrency());
        }

        if(purchaseAmountOptional1.isPresent()) {
            Amount Fee = purchaseAmountOptional1.get().getFee();
            System.out.println("fee applied value: " + Fee.getValue());
        }

        return ServiceResponse.success();
    }
}
