package com.dieboldnixdorf.sbt.trm.services;

import com.dieboldnixdorf.sbt.trm.SbtExtendedResponseCodes;
import com.dieboldnixdorf.sbt.trm.businessobjects.PurchaseAmount;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.ExtendedResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.container.TransactionStep;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumer;
import com.dieboldnixdorf.txm.core.businessmodel.services.*;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.ExtRspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.RspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.ServiceParameter;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.TransactionService;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Amount;
import com.myproclassic.common.tservices.tracelog.aspects.PCEAopTrace;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;

@PCEAopTrace
@ApplicationScoped
@TransactionService(id=LimitFeeDecision.SERVICE_ID,
                    usage = "Decide fee calculation based on Limit value",
                    serviceGroup = "SBT",
                    rspCodes = {
                        @RspCode(value = ResponseCode.OK, extRspCodes = {
                            @ExtRspCode(value = ExtendedResponseCode.OK_ID, name = "LimitFee not Required")
                        }),
                        @RspCode(value = ResponseCode.OK, extRspCodes = {
                            @ExtRspCode(value = SbtExtendedResponseCodes.FEE_REQUIRED_ID,
                                        name = "LimitFee Required")
                        }),
                        @RspCode(value = ResponseCode.FAIL, extRspCodes = {
                            @ExtRspCode(value = ExtendedResponseCode.SERVER_FAILURE_ID,
                                        name = "LimitFee decision Failed")
                        })
                    })
public class LimitFeeDecision implements Service {
    public static final String SERVICE_ID = "limitFeeDecision" ;

    @Inject
    @ServiceParameter(defaultValue = "5000")
    private Parameter<Long> limit;

    @Inject
    private FacetConsumer<PurchaseAmount> purchaseAmountFacetConsumer;

    @Override
    public ServiceResponse apply(TransactionStep transactionStep, Map<String, String> map) {
        return ServiceImplementation.create().apply(this::implementation, transactionStep, map);
    }

    private ServiceResponse implementation(TransactionStep transactionStep, Map<String, String> map){

        Optional<PurchaseAmount> purchaseAmountOptional = purchaseAmountFacetConsumer.getOptional();

        if(purchaseAmountOptional.isPresent()){
            Amount requestdAmount = purchaseAmountOptional.get().getRequestedAmount();
            long value = requestdAmount.getValue();

            if (value > limit.get().longValue()){
                return ServiceResponse.success(SbtExtendedResponseCodes.LIMIT_FEE_REQUIRED);
            } else {
                return ServiceResponse.success(ExtendedResponseCode.OK);
            }
        } else {
            return ServiceResponse.failure();
        }

    }
}
