package com.dieboldnixdorf.sbt.trm.services;

import com.dieboldnixdorf.sbt.trm.businessobjects.LimitFee;
import com.dieboldnixdorf.sbt.trm.businessobjects.PurchaseAmount;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.ExtendedResponseCode;
import com.dieboldnixdorf.txm.core.businessmodel.container.Request;
import com.dieboldnixdorf.txm.core.businessmodel.container.TransactionStep;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumer;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetConsumerStrategy;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetProducer;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetProducerStrategy;
import com.dieboldnixdorf.txm.core.businessmodel.services.*;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.ExtRspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.RspCode;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.ServiceParameter;
import com.dieboldnixdorf.txm.core.businessmodel.services.annotations.TransactionService;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Amount;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Currency;
import com.myproclassic.common.tservices.tracelog.aspects.PCEAopTrace;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;

@PCEAopTrace
@ApplicationScoped
@TransactionService(id=LimitFeeCalculation.SERVICE_ID,
                    usage = "Calculate Fee based on Limit",
                    serviceGroup = "SBT",
                    rspCodes = {
                        @RspCode(value = ResponseCode.OK, extRspCodes = {
                            @ExtRspCode(value = ExtendedResponseCode.OK_ID, name = "Fee Applied")
                        }),
                        @RspCode(value = ResponseCode.FAIL, extRspCodes = {
                            @ExtRspCode(value = ExtendedResponseCode.SERVER_FAILURE_ID, name = "Fee Calculation Failed")
                        })
                    })
public class LimitFeeCalculation implements Service {

    public static final String SERVICE_ID = "limitFeeCalculation";

    @Inject
    @FacetConsumerStrategy
    private FacetConsumer<PurchaseAmount> purchaseAmountFacetConsumer;

    @Inject
    @FacetProducerStrategy(value = Request.class)
    private FacetProducer<LimitFee> limitFeeFacetProducer;

    @Inject
    private FacetProducer<LimitFee> limitFeeFacetProducer1;

    @Inject
    @ServiceParameter(defaultValue = "2")
    private Parameter<Double> limitFeePercentValue;

    @Override
    public ServiceResponse apply(TransactionStep transactionStep, Map<String, String> map) {
        return ServiceImplementation.create().apply(this::implementation, transactionStep, map);
    }

    private ServiceResponse implementation(TransactionStep step, Map<String, String> parameter) {

        Optional<PurchaseAmount> purchaseAmountOptional = purchaseAmountFacetConsumer.getOptional();

        if(purchaseAmountOptional.isPresent()) {
            Amount requestedAmount = purchaseAmountOptional.get().getRequestedAmount();
            long value = requestedAmount.getValue();

            double fee = value * limitFeePercentValue.get().doubleValue() / 100;

            LimitFee limitFee = new LimitFee.Builder().
                    limitFeeValue(new Amount.Builder().value(Math.round(fee))
                            .currency(new Currency("USD", 840, 2)).build())
                            .build();

            limitFeeFacetProducer.set(limitFee);
            limitFeeFacetProducer1.set(limitFee);
            return ServiceResponse.success();
        } else {
            TrmServiceLogMessages.SERVICE_FAILED.log("Facet PurchaseAmount is missing in the request.");
            return ServiceResponse.failure();
        }

    }
}
