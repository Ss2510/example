package com.dieboldnixdorf.sbt.trm.tasks;

import com.dieboldnixdorf.sbt.trm.SBTTrmBusinessCases;
import com.dieboldnixdorf.sbt.trm.businessobjects.CustomerIdentification;
import com.dieboldnixdorf.sbt.trm.businessobjects.PurchaseAmount;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.BusinessCaseStep;
import com.dieboldnixdorf.txm.core.businessmodel.container.ClientContext;
import com.dieboldnixdorf.txm.core.businessmodel.container.Request;
import com.dieboldnixdorf.txm.core.businessmodel.container.Request.Header;
import com.dieboldnixdorf.txm.core.businessmodel.container.Response;
import com.dieboldnixdorf.txm.core.businessmodel.container.TransactionStep;
import com.dieboldnixdorf.txm.core.businessmodel.services.ResponseCode;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Amount;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Currency;
import com.dieboldnixdorf.txm.core.internal.businessmodel.cdi.context.CallContextHandler;
import com.dieboldnixdorf.txm.core.internal.businessmodel.services.bpm.BpmProcessContext;
import com.dieboldnixdorf.txm.core.internal.businessmodel.services.bpm.BpmProcessRegistry;
import com.myproclassic.common.types.PCEException;
import com.myproclassic.server.db.md.hierarchy.base.IPCEKernelNode;
import com.myproclassic.server.nodetaskscheduler.config.jobconfig.IJobConfig;
import com.myproclassic.server.nodetaskscheduler.config.task.ITask;
import com.myproclassic.server.nodetaskscheduler.processor.declarations.cdi.PCEJobProcessor;
import com.myproclassic.server.nodetaskscheduler.processor.ejb.ITaskRunContext;
import com.myproclassic.server.nodetaskscheduler.processor.ejb.PCEAbstractJobProcessor;
import com.myproclassic.server.nodetaskscheduler.result.ProcessResult;
import com.myproclassic.server.nodetaskscheduler.result.ValidationResult;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.time.Instant;
import java.util.UUID;

@ApplicationScoped
@PCEJobProcessor(id = "TrmScheduledTask")
public class TrmScheduledTask extends PCEAbstractJobProcessor {

    @Inject
    private BpmProcessRegistry bpmProcessRegistry;

    @Inject
    private CallContextHandler callContextHandler;

    @Override
    public ProcessResult process(IPCEKernelNode node, ITask task, ITaskRunContext ctx) throws PCEException {

        TransactionStep step = createTransactionStep();
        Response rsp = executeProcess(step);

        if (rsp.getHeader().getResponseCode() != ResponseCode.OK) {
            return new ProcessResult(ProcessResult.ResultCode.ERROR,
                    "Failed: (" + rsp.getHeader().getResponseCode() + "/" + rsp.getHeader().getExtendedResponseCode()
                            + ")");
        }
        return new ProcessResult(ProcessResult.ResultCode.OKAY, "Processed");
    }

    private TransactionStep createTransactionStep() {

        BusinessCaseStep bc = BusinessCaseStep.getByName("purchaseOrder.process");

        Header header = new Header.Builder()
                .businessCaseStep(SBTTrmBusinessCases.BC_PURCHASE_ORDER_PROCESS)
                .clientId("TrmScheduledTask")
                .time(Instant.now())
                .businessCorrelationId(UUID.randomUUID().toString())
                .boundedContext("trm")
                .build();

        Request request = new Request.Builder()
                .header(header)
                .build();

        // create purchase amount facet
        PurchaseAmount purchaseAmount = new PurchaseAmount.Builder()
                .requestedAmount(new Amount.Builder()
                        .value(10000)
                        .currency(new Currency("USD", 840, 2))
                        .build())
                .build();

        // add facet to request
        request.addFacet(purchaseAmount);

        // create customer id facet
        CustomerIdentification customerId = new CustomerIdentification.Builder()
                .id(UUID.randomUUID().toString())
                .build();

        // add facet to request
        request.addFacet(customerId);

        ClientContext newClientContext = new ClientContext(request.getHeader().getClientId());
        return newClientContext.createConsumerSession().createTransaction().createTransactionStep(request);
    }

    private Response executeProcess(TransactionStep step) {

        try (BpmProcessContext context = new BpmProcessContext(
                step.getTransaction().getConsumerSession().getClientContext())) {

            return callContextHandler.withProcessCallContext(context, () -> {
                bpmProcessRegistry.executeProcess(context);
                return context.getResponse();
            });
        }
    }

    @Override
    public ValidationResult validateJobConfig(IJobConfig config) {
        // optional - configuration validation
        return super.validateJobConfig(config);
    }

}
