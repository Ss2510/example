-- Configuration SQL-Script created by PC/E AdminConsole (c)2004-2012 Wincor-Nixdorf International GmbH
-- Owner    : PCEServer.NodeTaskScheduler
-- Section  : TrmScheduledTaskConfig
-- Hierarchy: DATACENTER

INSERT INTO Configuration(SECTIONID, NODEID, SECTIONNAME, OWNER, DESCRIPTION, PARENTID)
VALUES(3610952982062557274, (SELECT nodeId FROM DataCenter WHERE defDC=1),
       'TrmScheduledTaskConfig', 'PCEServer.NodeTaskScheduler',
       'NodeTaskScheduler job config section', 2279401582890983958);

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(3919616848339963148, 1, 3610952982062557274, 'SpecificForJobProcessor');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(3919616848339963148, 0,
       'TrmScheduledTask', 'NodeTaskScheduler job config parameter');

-- Configuration SQL-Script created by OCM
-- Owner    : PCEServer.NodeTaskScheduler
-- Section  : TrmScheduledTask
-- Hierarchy: DATACENTER

INSERT INTO Configuration(SECTIONID, NODEID, SECTIONNAME, OWNER, DESCRIPTION, PARENTID, ACCESSMODE)
VALUES(8625766777662570582, (SELECT nodeId FROM DataCenter WHERE defDC=1),
       'TrmScheduledTask', 'PCEServer.NodeTaskScheduler',
       'NodeTaskScheduler section', 2279402155145044514, null);

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(-5889193769693011043, 1, 8625766777662570582, 'Job', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-5889193769693011043, 0,
       'TrmScheduledTask', 'NodeTaskScheduler task config parameter');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(-5889193767843494031, 1, 8625766777662570582, 'FreeInterval', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-5889193767843494031, 0,
       '10[s]', 'NodeTaskScheduler task config parameter');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(-5889193767022253761, 1, 8625766777662570582, 'JobConfig', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-5889193767022253761, 0,
       'TrmScheduledTaskConfig', 'NodeTaskScheduler task config parameter');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(-5889193767354422563, 1, 8625766777662570582, 'NodeId', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-5889193767354422563, 0,
       '0', 'NodeTaskScheduler task config parameter');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(-5889193767282019851, 1, 8625766777662570582, 'MarkerMaxAge', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-5889193767282019851, 0,
       '1', 'NodeTaskScheduler task config parameter');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(-5889193767737201882, 1, 8625766777662570582, 'Active', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-5889193767737201882, 0,
       'false', 'NodeTaskScheduler task config parameter');