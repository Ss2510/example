INSERT INTO Configuration(SECTIONID, NODEID, SECTIONNAME, OWNER, DESCRIPTION, PARENTID)
VALUES(1532663366922, (SELECT nodeId FROM DataCenter WHERE defDC=1),
       'EIS_JSON', 'EIS.EISConnector.ConnectionDefs.HTTP',
       'Default section.', 1529175840530);

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1533937441112, 0, 1532663366922, 'ConnectMode');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1533937441112, 0,
       '0', 'Connect/disconnect handling. 0 = keep connected. 3 = the connection is destroyed on close() and created on getConnection(');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(-2748598276735900351, 0, 1532663366922, 'Timeout');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-2748598276735900351, 0,
       '5000', 'Default timeout.');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1533550011241, 0, 1532663366922, 'URI');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1533550011241, 0,
       'http://localhost:1235/tejp', 'Absolute or relative uri of requested resource.');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1531371175243, 0, 1532663366922, 'SendMethod');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1531371175243, 0,
       'POST', 'use GET or POST');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1530597111819, 0, 1532663366922, 'ContentType');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1530597111819, 0,
       'application/json', 'use valid value or leave blank');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(-2748598274212680944, 0, 1532663366922, 'HttpVersion');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(-2748598274212680944, 0,
       'HTTP/1.1', 'use HTTP/1.1 or other.');

INSERT INTO Configuration(SECTIONID, NODEID, SECTIONNAME, OWNER, DESCRIPTION, PARENTID)
VALUES(1533501224414, (SELECT nodeId FROM DataCenter WHERE defDC=1),
       'EIS_JSON', 'EIS.EISConnector.Connectors',
       'EIS_JSON connector', 1516171246713);

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1533188548671, 0, 1533501224414, 'ConnectionType');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1533188548671, 0,
       'HTTP', 'Connection type');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1534093974657, 0, 1533501224414, 'ConnectorState');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1534093974657, 0,
       'RUNNING', 'Allowed values: RUNNING, STOPPED.');

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME)
VALUES(1531367428710, 0, 1533501224414, 'ConnectionDef');
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(1531367428710, 0,
       'EIS_JSON', 'Connection definition');

UPDATE ConfigValue SET VALUE=VALUE || ',authorizationHost' WHERE KEYID=-742267445322295959;
INSERT INTO rule (id, ruleset, name, nodeid, priority, condition, result, description)
VALUES ('e0d0e5c9aef249b29a84553adbc87a7d', 'authorizationHost', 'authorizePurchaseOrder',
        0, 5, '${businessCase == ''purchaseOrder''}',
        '{"service":{"implementation":"JsonConnector","parameter":{"connector":"EIS_JSON"}}}',
        'routing to external authorization host');

INSERT INTO Configuration(SECTIONID, NODEID, SECTIONNAME, OWNER, DESCRIPTION, PARENTID, ACCESSMODE)
VALUES(335969935891628621, (SELECT nodeId FROM DataCenter WHERE defDC=1),
       'FeeCalculationTimeout', 'SBT',
       'Tiemout value', null, null);

INSERT INTO ConfigParam(KEYID, ACCESSMODE, SECTIONID, KEYNAME, ACCESSTYPE)
VALUES(7539475123866973310, 6, 335969935891628621, 'feeCalculationTimeout', null);
INSERT INTO ConfigValue(KEYID, NODEID, VALUE, DESCRIPTION)
VALUES(7539475123866973310, 0,
       '1', 'Timeout Value');

INSERT INTO rule (id, ruleset, name, nodeid, priority, condition, result, description)
VALUES ('e1b84271251e4750aeedda6d82416df0', 'postProcess.purchaseOrder', 'Purchase order post processing',
        0, 5, '${committed and businessCase=="purchaseOrder"}',
        '{"flow": "postprocessPurchaseOrder.bpmn"}',
        'Purchase order post processing rule');

UPDATE ConfigValue SET VALUE=VALUE || ',bcReport' WHERE KEYID=-742267445322295959;
INSERT INTO rule (id, ruleset, name, nodeid, priority, condition, result, description)
VALUES ('4f0140e174254a29b449e8244296cfeb', 'bcReport', 'purchaseOrderReport',
        0, 5, '${businessCase == ''purchaseOrder''}',
        '{"service":{"implementation":"JsonConnector","parameter":{"connector":"BC_REPORT"}}}',
        'routing to BC Report for purchase Order');
