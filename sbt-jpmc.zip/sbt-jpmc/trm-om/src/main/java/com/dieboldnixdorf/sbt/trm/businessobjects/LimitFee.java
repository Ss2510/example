package com.dieboldnixdorf.sbt.trm.businessobjects;


import com.dieboldnixdorf.txm.core.businessmodel.BusinessObject;
import com.dieboldnixdorf.txm.core.businessmodel.BusinessObjectBuilder;
import com.dieboldnixdorf.txm.core.businessmodel.BusinessObjectMarker;
import com.dieboldnixdorf.txm.core.businessmodel.Factory;
import com.dieboldnixdorf.txm.core.businessmodel.facets.FacetMarker;
import com.dieboldnixdorf.txm.core.businessobjects.financial.amount.Amount;
import com.fasterxml.jackson.annotation.JsonProperty;

@FacetMarker(value = LimitFee.FACET_ID)
@BusinessObjectMarker
public class LimitFee extends BusinessObject {
    public static final String FACET_ID = "limitFee";
    private static final long serialVersionUID = 1L;

    @JsonProperty
    protected Amount limitFeeValue;

    protected static abstract class AbstractBuilder<B extends BusinessObjectBuilder<B, T>, T extends LimitFee>
        extends BusinessObjectBuilder<B, T>{

        public B limitFeeValue(Amount limitFeeValue){
            newObject.limitFeeValue = limitFeeValue;
            return  getThis();
        }

    }

    public static class Builder extends AbstractBuilder<Builder, LimitFee>{

        @Override
        protected LimitFee createInstance() {
            return Factory.createInstance(LimitFee.class);
        }
    }

    public Amount getLimitFeeValue(){
        return limitFeeValue;
    }
}
