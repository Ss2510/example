package com.dieboldnixdorf.sbt.trm;

import com.dieboldnixdorf.txm.core.businessmodel.EnumerationMarker;
import com.dieboldnixdorf.txm.core.businessmodel.businessobjects.ExtendedResponseCode;

@EnumerationMarker
public class SbtExtendedResponseCodes {
    public static final String FEE_REQUIRED_ID = "FEE_REQUIRED";
    public static final String LIMIT_FEE_REQUIRED_ID = "LIMIT_FEE_REQUIRED";
    public static final ExtendedResponseCode FEE_REQUIRED = new ExtendedResponseCode(FEE_REQUIRED_ID);
    public static final ExtendedResponseCode LIMIT_FEE_REQUIRED = new ExtendedResponseCode(LIMIT_FEE_REQUIRED_ID);
}
