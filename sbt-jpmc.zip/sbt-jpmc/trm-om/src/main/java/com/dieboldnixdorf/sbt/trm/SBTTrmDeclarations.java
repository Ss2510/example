package com.dieboldnixdorf.sbt.trm;

public class SBTTrmDeclarations {
    public static final int COMPONENT_NUMBER_RANGE_START = 9_000_000;
}
